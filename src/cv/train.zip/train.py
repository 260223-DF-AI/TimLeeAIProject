import os
import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

from src.cv.model import CatDogModel

def train():
    print("starting training")
    training_dir = os.environ["SM_CHANNEL_TRAINING"]
    model_dir = os.environ["SM_MODEL_DIR"]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    transform = transforms.Compose([
        transforms.Resize((224,224)),
        transforms.ToTensor()
    ])

    dataset = datasets.ImageFolder(
        training_dir,
        transform=transform
    )

    print("dataset size:", len(dataset))
    print("classes:", dataset.classes)

    loader = DataLoader(dataset, batch_size=32, shuffle=True)

    model = CatDogModel().to(device)
    model.train()

    loss_fn = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters())
    print("first loop")
    for epoch in range(5):
        
        total_loss = 0.0

        for x, y in loader:
            x, y = x.to(device), y.to(device)

            pred = model(x)
            loss = loss_fn(pred, y)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        print(f"epoch {epoch} loss: {total_loss:.4f}", flush=True)

    torch.save(model.state_dict(), f"{model_dir}/model.pth")
    print("model saved")

if __name__ == "__main__":
    train()
